pub(crate) mod bird;

use crate::dragon::bird::animal::obj::*;
use crate::dragon::bird::animal::*;

use bird::BirdArchetype;
use bird::BirdTrait;

struct DragonArchetype {
    bird: BirdArchetype,
    eggs: u32,
}

impl DragonArchetype {
    fn fire(&self) {
        println!("DragonArchetype::fire");
    }
    fn try_reproduce(&mut self) -> Option<DragonArchetype> {
        if self.eggs > 0 {
            self.bird
                .animal
                .calories
                .checked_sub(50)
                .map(|remaining_calories| {
                    self.bird.animal.calories = remaining_calories;
                    self.eggs -= 1;
                    DragonArchetype {
                        bird: self.bird.clone(),
                        eggs: self.eggs,
                    }
                })
        } else {
            None
        }
    }
}

trait DragonTrait: BirdTrait {
    // fn try_reproduce(&mut self) -> Option<Dragon>;
    fn fire(&self);
}

struct Dragon {
    dragon: DragonArchetype,
}

impl Dragon {
    pub fn new(dragon: DragonArchetype) -> Self {
        Self { dragon }
    }
}

impl ObjTrait for Dragon {}

impl AnimalTrait for Dragon {
    fn eat(&mut self, calories: u32) {
        self.dragon.bird.animal.eat(calories)
    }
}

impl BirdTrait for Dragon {
    type Offspring = Dragon;

    fn peep(&self) {
        self.dragon.bird.peep()
    }

    fn try_reproduce(&mut self) -> Option<Self::Offspring> {
        self.dragon
            .try_reproduce()
            .map(|dragon: DragonArchetype| Self::Offspring { dragon })
    }
}

impl DragonTrait for Dragon {
    fn fire(&self) {
        self.dragon.fire();
    }
}

pub fn dragon_main() {
    let mut dragon = Dragon::new(DragonArchetype {
        bird: BirdArchetype {
            animal: AnimalArchetype {
                obj: ObjArchetype {
                    obj_id: "1".to_string(),
                    obj_type: ObjType::Dragon,
                },
                calories: 10,
            },
            eggs: 3,
        },
        eggs: 4,
    });
    dragon.fire();
    dragon.eat(50);
    dragon.peep();
    if let Some(mut new_dragon) = dragon.try_reproduce() {
        dragons_only(&dragon);
        dragons_only(&new_dragon);
        new_dragon.eat(50);
    }
}

fn dragons_only(dragon: &impl DragonTrait) {
    dragon.fire();
}
