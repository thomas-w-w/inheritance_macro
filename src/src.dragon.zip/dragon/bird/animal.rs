pub(crate) mod obj;

use obj::{ObjArchetype, ObjTrait};

#[derive(Clone)]
pub(crate) struct AnimalArchetype {
    pub(crate) obj: ObjArchetype,
    pub(crate) calories: u32,
}

impl AnimalArchetype {
    pub(crate) fn eat(&mut self, calories: u32) {
        self.calories += calories;
    }
}

pub(crate) trait AnimalTrait: ObjTrait {
    fn eat(&mut self, calories: u32);
}

struct Animal {
    animal: AnimalArchetype,
}

impl ObjTrait for Animal {}

impl AnimalTrait for Animal {
    fn eat(&mut self, calories: u32) {
        self.animal.eat(calories);
    }
}
